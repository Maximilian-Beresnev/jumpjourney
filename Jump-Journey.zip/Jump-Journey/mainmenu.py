import pygame
import sys
import spiel
import math
from screeninfo import get_monitors

pygame.init()

# Bildschirm holen
monitor = get_monitors()[0]
SCREEN_WIDTH, SCREEN_HEIGHT = monitor.width, monitor.height
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)

FPS = 120
clock = pygame.time.Clock()
 
# Sound
click_sound = pygame.mixer.Sound("Music/rollover1.ogg")
swipe_sound = pygame.mixer.Sound("Music/swipe1.ogg")
click_sound.set_volume(0.50)
swipe_sound.set_volume(0.50)

reset_music_on_exit = True
pygame.display.set_caption("Menu")

# Backgrounds
background = pygame.transform.smoothscale(pygame.image.load("Background/tbg3.png").convert(), (SCREEN_WIDTH, SCREEN_HEIGHT))
background_welt1 = pygame.transform.smoothscale(pygame.image.load("testbg.png").convert(), (SCREEN_WIDTH, SCREEN_HEIGHT))
background_welt2 = pygame.transform.smoothscale(pygame.image.load("Background/wueste5.png").convert(), (SCREEN_WIDTH, SCREEN_HEIGHT))

# Titel
title_raw = pygame.image.load("schrift.png").convert_alpha()
title_scale = SCREEN_WIDTH / 3840 * 1.0  # dynamisch
title_size = (int(title_raw.get_width() * title_scale), int(title_raw.get_height() * title_scale))
title_img = pygame.transform.smoothscale(title_raw, title_size)
title_rect = title_img.get_rect(midtop=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 15))

# Button-Größe dynamisch
BUTTON_WIDTH = SCREEN_WIDTH // 5
BUTTON_HEIGHT = SCREEN_HEIGHT // 10
SPACING = SCREEN_HEIGHT // 40
HOVER_SCALE = 1.08
FADE_IN_DURATION = 30
FADE_OUT_DURATION = 30

def load_button(path):
    img = pygame.image.load(path).convert_alpha()
    return pygame.transform.smoothscale(img, (BUTTON_WIDTH, BUTTON_HEIGHT))

def create_button_states(path):
    normal = load_button(path)
    w, h = normal.get_size()
    hover = pygame.transform.smoothscale(normal, (int(w * HOVER_SCALE), int(h * HOVER_SCALE)))
    return {"normal": normal, "hover": hover}

buttons = {
    "Play": create_button_states("play2.png"),
    "Settings": create_button_states("settings2.png"),
    "Quit": create_button_states("quit2.png")
}

center_buttons = ["Play", "Settings", "Quit"]
total_height = len(center_buttons) * BUTTON_HEIGHT + (len(center_buttons) - 1) * SPACING
start_y = (SCREEN_HEIGHT - total_height) // 2
center_x = (SCREEN_WIDTH - BUTTON_WIDTH) // 2

button_rects = {name: pygame.Rect(center_x, start_y + i * (BUTTON_HEIGHT + SPACING), BUTTON_WIDTH, BUTTON_HEIGHT)
                for i, name in enumerate(center_buttons)}

def fade(surface, alpha):
    overlay = pygame.Surface(surface.get_size())
    overlay.fill((0, 0, 0))
    overlay.set_alpha(alpha)
    surface.blit(overlay, (0, 0))

def fade_out():
    for i in range(FADE_OUT_DURATION):
        draw_menu()
        fade(screen, int((i / FADE_OUT_DURATION) * 255))
        pygame.display.flip()
        clock.tick(FPS)

def fade_in():
    for i in range(FADE_IN_DURATION):
        draw_menu()
        fade(screen, 255 - int((i / FADE_IN_DURATION) * 255))
        pygame.display.flip()
        clock.tick(FPS)

def draw_menu():
    screen.blit(background, (0, 0))
    time_now = pygame.time.get_ticks() / 1000
    float_offset = math.sin(time_now * 2) * SCREEN_HEIGHT * 0.01
    title_rect.y = (SCREEN_HEIGHT // 15) + int(float_offset)
    screen.blit(title_img, title_rect)
    mouse_pos = pygame.mouse.get_pos()
    for name, rect in button_rects.items():
        hovered = rect.collidepoint(mouse_pos)
        img = buttons[name]["hover"] if hovered else buttons[name]["normal"]
        screen.blit(img, img.get_rect(center=rect.center))

def play_click_sound():
    click_sound.play()

def play_swipe_sound():
    swipe_sound.play()

def animate_start():
    duration = 1000
    start_time = pygame.time.get_ticks()

    button_states = []
    for i, name in enumerate(center_buttons):
        rect = button_rects[name]
        start_y = rect.y + SCREEN_HEIGHT // 8
        button_states.append({
            "name": name,
            "start_y": start_y,
            "end_y": rect.y,
            "delay": i * 120,
            "rect": rect
        })

    while True:
        elapsed = pygame.time.get_ticks() - start_time
        screen.blit(background, (0, 0))

        progress = min(elapsed / duration, 1)
        eased = 1 - pow(1 - progress, 3)
        current_y = int(-SCREEN_HEIGHT // 5 + (title_rect.y + SCREEN_HEIGHT // 5) * eased)
        alpha = int(eased * 255)
        temp_title = title_img.copy()
        temp_title.set_alpha(alpha)
        screen.blit(temp_title, (title_rect.x, current_y))

        all_done = True
        for state in button_states:
            btn_elapsed = elapsed - state["delay"]
            if btn_elapsed < 0:
                all_done = False
                continue
            btn_progress = min(btn_elapsed / 600, 1)
            eased_btn = 1 - pow(1 - btn_progress, 3)
            offset = int((1 - eased_btn) * SCREEN_HEIGHT * 0.05)
            y = state["end_y"] + offset
            alpha = int(eased_btn * 255)

            img = buttons[state["name"]]["normal"].copy()
            img.set_alpha(alpha)
            img_rect = img.get_rect(center=(state["rect"].centerx, y + BUTTON_HEIGHT // 2))
            screen.blit(img, img_rect)

            if btn_progress < 1:
                all_done = False

        pygame.display.flip()
        clock.tick(FPS)

        if progress >= 1.0 and all_done:
            break

def level_select():
    button_size = SCREEN_HEIGHT // 8
    spacing = SCREEN_WIDTH // 30

    level_buttons = {}
    hover_buttons = {}
    for lvl in range(1, 9):
        img = pygame.transform.smoothscale(pygame.image.load(f"Menu/{lvl}.png"), (button_size, button_size))
        level_buttons[str(lvl)] = img
        hover_buttons[str(lvl)] = pygame.transform.smoothscale(img, (int(button_size * 1.15), int(button_size * 1.15)))

    label_w = SCREEN_WIDTH // 4
    label_h = SCREEN_HEIGHT // 7.3
    welt_labels = {
        0: pygame.transform.smoothscale(pygame.image.load("Menu/testwelt1.png"), (label_w, label_h)),
        1: pygame.transform.smoothscale(pygame.image.load("Menu/testwelt2.png"), (label_w, label_h))
    }
    welt_rect = welt_labels[0].get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 6))

    arrow_size = SCREEN_HEIGHT // 9.3
    arrow_hover = int(arrow_size * 1.15)

    pfeil_links = pygame.transform.smoothscale(pygame.image.load("Menu/pfeil_links.png"), (arrow_size, arrow_size))
    pfeil_rechts = pygame.transform.smoothscale(pygame.image.load("Menu/pfeil_rechts.png"), (arrow_size, arrow_size))
    pfeil_links_hover = pygame.transform.smoothscale(pfeil_links, (arrow_hover, arrow_hover))
    pfeil_rechts_hover = pygame.transform.smoothscale(pfeil_rechts, (arrow_hover, arrow_hover))
    pfeil_links2 = pygame.transform.smoothscale(pygame.image.load("Menu/pfeil_links2.png"), (arrow_size, arrow_size))
    pfeil_rechts2 = pygame.transform.smoothscale(pygame.image.load("Menu/pfeil_rechts2.png"), (arrow_size, arrow_size))
    pfeil_links2_hover = pygame.transform.smoothscale(pfeil_links2, (arrow_hover, arrow_hover))
    pfeil_rechts2_hover = pygame.transform.smoothscale(pfeil_rechts2, (arrow_hover, arrow_hover))

    pfeil_links_rect = pfeil_links.get_rect(center=(int(SCREEN_WIDTH // 3.1), SCREEN_HEIGHT // 6))
    pfeil_rechts_rect = pfeil_rechts.get_rect(center=(int(SCREEN_WIDTH - SCREEN_WIDTH // 3.1), SCREEN_HEIGHT // 6))
    pfeil_links2_rect = pfeil_links2.get_rect(center=(int(SCREEN_WIDTH // 3.1), SCREEN_HEIGHT // 6))
    pfeil_rechts2_rect = pfeil_rechts2.get_rect(center=(int(SCREEN_WIDTH - SCREEN_WIDTH // 3.1), SCREEN_HEIGHT // 6))

    back_w = SCREEN_WIDTH // 8
    back_h = SCREEN_HEIGHT // 12
    back_hover = int(back_w * 1.15), int(back_h * 1.15)
    back_img = pygame.transform.smoothscale(pygame.image.load("Menu/back.png").convert_alpha(), (back_w, back_h))
    back_img_hover = pygame.transform.smoothscale(pygame.image.load("Menu/back.png").convert_alpha(), back_hover)
    back_rect = back_img.get_rect(bottomright=(SCREEN_WIDTH - spacing, SCREEN_HEIGHT - spacing - -27))

    start_x = (SCREEN_WIDTH - (4 * button_size + 3 * spacing)) // 2
    y1 = SCREEN_HEIGHT // 3
    y2 = y1 + button_size + spacing

    button_rects_levels = {}
    current_page = 0

    def draw_level_buttons(page, offset_x=0):
        mouse_pos = pygame.mouse.get_pos()
        for i, lvl in enumerate(["1", "2", "3", "4"]):
            rect = pygame.Rect(start_x + i * (button_size + spacing) + offset_x, y1, button_size, button_size)
            img = hover_buttons[lvl] if rect.collidepoint(mouse_pos) and page == current_page else level_buttons[lvl]
            screen.blit(img, img.get_rect(center=rect.center))
            if page == current_page:
                button_rects_levels[lvl] = rect
        for i, lvl in enumerate(["5", "6", "7", "8"]):
            rect = pygame.Rect(start_x + i * (button_size + spacing) + offset_x, y2, button_size, button_size)
            img = hover_buttons[lvl] if rect.collidepoint(mouse_pos) and page == current_page else level_buttons[lvl]
            screen.blit(img, img.get_rect(center=rect.center))
            if page == current_page:
                button_rects_levels[lvl] = rect

    def draw_arrows(page, offset_x=0):
        mouse_pos = pygame.mouse.get_pos()
        if page == 0:
            screen.blit(pfeil_links_hover if pfeil_links_rect.collidepoint(mouse_pos) else pfeil_links, pfeil_links_rect.move(offset_x, 0))
            screen.blit(pfeil_rechts_hover if pfeil_rechts_rect.collidepoint(mouse_pos) else pfeil_rechts, pfeil_rechts_rect.move(offset_x, 0))
        else:
            screen.blit(pfeil_links2_hover if pfeil_links2_rect.collidepoint(mouse_pos) else pfeil_links2, pfeil_links2_rect.move(offset_x, 0))
            screen.blit(pfeil_rechts2_hover if pfeil_rechts2_rect.collidepoint(mouse_pos) else pfeil_rechts2, pfeil_rechts2_rect.move(offset_x, 0))

    def slide_background(from_bg, to_bg, from_label, to_label, from_page, to_page, direction):
        duration = 500
        start_time = pygame.time.get_ticks()
        while pygame.time.get_ticks() - start_time < duration:
            elapsed = pygame.time.get_ticks() - start_time
            t = min(1, elapsed / duration)
            offset = int(SCREEN_WIDTH * t)
            dir_mult = -1 if direction == "left" else 1
            from_x = offset * dir_mult
            to_x = (offset - SCREEN_WIDTH) * dir_mult
            screen.blit(from_bg, (from_x, 0))
            screen.blit(to_bg, (to_x, 0))
            screen.blit(from_label, from_label.get_rect(center=(SCREEN_WIDTH // 2 + from_x, welt_rect.centery)))
            screen.blit(to_label, to_label.get_rect(center=(SCREEN_WIDTH // 2 + to_x, welt_rect.centery)))
            draw_level_buttons(from_page, offset_x=from_x)
            draw_level_buttons(to_page, offset_x=to_x)
            draw_arrows(from_page, offset_x=from_x)
            draw_arrows(to_page, offset_x=to_x)
            pygame.display.flip()
            clock.tick(FPS)

    running = True
    while running:
        bg = background_welt1 if current_page == 0 else background_welt2
        screen.blit(bg, (0, 0))
        screen.blit(welt_labels[current_page], welt_rect)
        draw_level_buttons(current_page)
        draw_arrows(current_page)

        mouse_pos = pygame.mouse.get_pos()
        screen.blit(back_img_hover if back_rect.collidepoint(mouse_pos) else back_img, back_rect)

        pygame.display.flip()
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if back_rect.collidepoint(event.pos):
                    play_click_sound()
                    return
                if current_page == 0 and pfeil_rechts_rect.collidepoint(event.pos):
                    play_swipe_sound()
                    slide_background(background_welt1, background_welt2, welt_labels[0], welt_labels[1], 0, 1, "left")
                    current_page = 1
                elif current_page == 1 and pfeil_links2_rect.collidepoint(event.pos):
                    play_swipe_sound()
                    slide_background(background_welt2, background_welt1, welt_labels[1], welt_labels[0], 1, 0, "right")
                    current_page = 0
                else:
                    for lvl, rect in button_rects_levels.items():
                        if rect.collidepoint(event.pos):
                            play_click_sound()
                            if current_page == 0 and lvl == "1":
                                music_pos = pygame.mixer.music.get_pos() / 1000
                                pygame.mixer.music.stop()
                                fade_out()
                                spiel.run_game_loop(screen, clock, fade_in, fade_out, "player")
                                pygame.mixer.music.load("Music/musicmenu.ogg")
                                pygame.mixer.music.set_volume(0.31)
                                pygame.mixer.music.play(-1, start=music_pos if not reset_music_on_exit else 0)
                            else:
                                print(f"Level {lvl} in Welt {current_page + 1} ist noch nicht freigeschaltet.")

def main_menu():
    animate_start()
    running = True
    while running:
        draw_menu()
        pygame.display.flip()
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for name, rect in button_rects.items():
                    if rect.collidepoint(event.pos):
                        play_click_sound()
                        if name == "Quit":
                            running = False
                        elif name == "Play":
                            level_select()
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    pygame.mixer.music.load("Music/musicmenu.ogg")
    pygame.mixer.music.set_volume(0.30)
    pygame.mixer.music.play(-1)
    main_menu()

import pygame
import sys
import os
from screeninfo import get_monitors

pygame.init()
pygame.mixer.init()

COIN_SOUND_ENABLED = False  # Wenn du coin.ogg hast, auf True setzen

TARGET_WIDTH = 1920
TARGET_HEIGHT = 1080

monitor = get_monitors()[0]
SCREEN_WIDTH, SCREEN_HEIGHT = monitor.width, monitor.height

FPS = 120
clock = pygame.time.Clock()

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Skalierte Version")

game_surface = pygame.Surface((TARGET_WIDTH, TARGET_HEIGHT))

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

background = pygame.image.load("testbg.png")
background = pygame.transform.scale(background, (TARGET_WIDTH, TARGET_HEIGHT))
button_play = pygame.image.load("play2.png").convert_alpha()
button_settings = pygame.image.load("settings2.png").convert_alpha()
button_quit = pygame.image.load("quit2.png").convert_alpha()
schrift = pygame.image.load("schrift.png").convert_alpha()
coin_image = pygame.image.load("Level/coin.png").convert_alpha()

button_scale = 0.7
button_size = (int(button_play.get_width() * button_scale), int(button_play.get_height() * button_scale))
button_play = pygame.transform.smoothscale(button_play, button_size)
button_settings = pygame.transform.smoothscale(button_settings, button_size)
button_quit = pygame.transform.smoothscale(button_quit, button_size)
schrift = pygame.transform.smoothscale(schrift, (500, 200))
coin_image = pygame.transform.smoothscale(coin_image, (50, 50))

click_sound = pygame.mixer.Sound("Music/rollover1.ogg")
click_sound.set_volume(0.3)

if COIN_SOUND_ENABLED:
    coin_sound = pygame.mixer.Sound("coin.ogg")
    coin_sound.set_volume(0.4)
else:
    coin_sound = None

pause_buttons_y_start = 400
pause_button_spacing = 130
GROUND_HEIGHT = 270

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image_orig = pygame.image.load("Level/platform.png").convert_alpha()
        self.image = pygame.transform.scale(self.image_orig, (150, 25))
        self.rect = self.image.get_rect(topleft=(x, y))

class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = coin_image
        self.rect = self.image.get_rect(center=(x, y))

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.scale = 1.0

        self.sprites = {
            "idle": pygame.image.load("Character/male2/character_maleAdventurer_idle.png"),
            "walk": [pygame.image.load(f"Character/male2/character_maleAdventurer_walk{i}.png") for i in range(8)],
            "jump": pygame.image.load("Character/male2/character_maleAdventurer_fall.png"),
            "duck": pygame.image.load("Character/male2/character_maleAdventurer_duck.png"),
            "hurt": pygame.image.load("Character/male2/character_maleAdventurer_hurt.png"),
            "cheer": [pygame.image.load("Character/male2/character_maleAdventurer_cheer0.png"),
                      pygame.image.load("Character/male2/character_maleAdventurer_cheer1.png")]
        }

        self.sprites["walk"] = [pygame.transform.scale(img, (int(img.get_width()*self.scale), int(img.get_height()*self.scale))) for img in self.sprites["walk"]]
        walk_w = self.sprites["walk"][0].get_width()
        walk_h = self.sprites["walk"][0].get_height()

        self.sprint_sprites = [
            pygame.image.load("Character/male2/character_maleAdventurer_run1.png"),
            pygame.image.load("Character/male2/character_maleAdventurer_run2.png")
        ]
        self.sprint_sprites = [pygame.transform.scale(img, (walk_w, walk_h)) for img in self.sprint_sprites]

        for key in ["idle", "jump", "duck", "hurt"]:
            self.sprites[key] = pygame.transform.scale(self.sprites[key], (int(self.sprites[key].get_width()*self.scale), int(self.sprites[key].get_height()*self.scale)))
        for i in range(len(self.sprites["cheer"])):
            self.sprites["cheer"][i] = pygame.transform.scale(self.sprites["cheer"][i], (int(self.sprites["cheer"][i].get_width()*self.scale), int(self.sprites["cheer"][i].get_height()*self.scale)))

        self.image = self.sprites["idle"]
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = TARGET_HEIGHT - GROUND_HEIGHT - self.rect.height - 50

        self.vel_x = 0
        self.vel_y = 0
        self.jumping = False
        self.ducking = False
        self.facing_right = True
        self.walk_timer = 0
        self.dead = False
        self.cheering = False
        self.sprinting = False

    def update(self, keys, platforms):
        if self.dead:
            self.image = self.sprites["hurt"]
            return

        if self.cheering:
            index = int(pygame.time.get_ticks() / 250) % 2
            self.image = self.sprites["cheer"][index]
            return

        self.ducking = keys[pygame.K_s] and not self.jumping

        sprinting = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]

        speed = 2 if self.ducking else 5
        if sprinting:
            speed += 1.2  # Sprint leicht schneller
        self.sprinting = sprinting

        self.vel_x = 0
        if keys[pygame.K_d]:
            self.vel_x = speed
            self.facing_right = True
        elif keys[pygame.K_a]:
            self.vel_x = -speed
            self.facing_right = False

        self.rect.x += self.vel_x

        if (keys[pygame.K_w] or keys[pygame.K_SPACE]) and not self.jumping and not self.ducking:
            self.vel_y = -15
            self.jumping = True

        self.vel_y += 0.8
        self.rect.y += self.vel_y

        for platform in platforms:
            if self.vel_y > 0 and self.rect.colliderect(platform.rect):
                if self.rect.bottom <= platform.rect.bottom and self.rect.bottom + self.vel_y >= platform.rect.top:
                    self.rect.bottom = platform.rect.top
                    self.vel_y = 0
                    self.jumping = False

        if self.rect.bottom >= TARGET_HEIGHT - GROUND_HEIGHT:
            self.rect.bottom = TARGET_HEIGHT - GROUND_HEIGHT
            self.vel_y = 0
            self.jumping = False

        if self.ducking:
            self.image = self.sprites["duck"]
        elif self.jumping:
            self.image = self.sprites["jump"]
        elif self.vel_x != 0:
            self.walk_timer += 0.2
            idx = int(self.walk_timer) % len(self.sprites["walk"])
            if self.sprinting:
                self.image = self.sprint_sprites[idx % 2]
            else:
                self.image = self.sprites["walk"][idx]
        else:
            self.image = self.sprites["idle"]

        if not self.facing_right:
            self.image = pygame.transform.flip(self.image, True, False)

    def die(self):
        self.dead = True

    def cheer(self):
        self.cheering = True

platforms = pygame.sprite.Group(
    Platform(400, 710),
    Platform(600, 620),
    Platform(850, 530),
    Platform(1100, 440),
    Platform(1300, 550),
    Platform(1600, 470)
)

initial_coin_positions = [
    (420, 660),
    (620, 570),
    (870, 480),
    (1120, 390),
    (1320, 500),
    (1620, 420)
]

def create_coins():
    return pygame.sprite.Group([Coin(x, y) for x, y in initial_coin_positions])

coins = create_coins()

def draw_ground(surface):
    try:
        ground_img = pygame.image.load("gp2.png").convert_alpha()
        ground_img = pygame.transform.scale(ground_img, (100, GROUND_HEIGHT))
        for x in range(0, TARGET_WIDTH, 100):
            surface.blit(ground_img, (x, TARGET_HEIGHT - GROUND_HEIGHT))
    except:
        pygame.draw.rect(surface, (0, 200, 0), (0, TARGET_HEIGHT - GROUND_HEIGHT, TARGET_WIDTH, GROUND_HEIGHT))

def draw_pause_menu():
    overlay = pygame.Surface((TARGET_WIDTH, TARGET_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    game_surface.blit(overlay, (0, 0))
    game_surface.blit(schrift, (TARGET_WIDTH//2 - schrift.get_width()//2, 150))
    buttons = [button_play, button_settings, button_quit]
    for i, button in enumerate(buttons):
        x = TARGET_WIDTH//2 - button.get_width()//2
        y = pause_buttons_y_start + i * pause_button_spacing
        rect = pygame.Rect(x, y, button.get_width(), button.get_height())
        if rect.collidepoint(pygame.mouse.get_pos()[0] * TARGET_WIDTH // SCREEN_WIDTH,
                             pygame.mouse.get_pos()[1] * TARGET_HEIGHT // SCREEN_HEIGHT):
            button = pygame.transform.smoothscale(button, (int(button.get_width() * 1.05), int(button.get_height() * 1.05)))
            rect = button.get_rect(center=rect.center)
        game_surface.blit(button, rect.topleft)
    scaled_surface = pygame.transform.scale(game_surface, (SCREEN_WIDTH, SCREEN_HEIGHT))
    screen.blit(scaled_surface, (0, 0))
    pygame.display.flip()
    return [pygame.Rect(TARGET_WIDTH//2 - b.get_width()//2, pause_buttons_y_start + i * pause_button_spacing,
                        b.get_width(), b.get_height()) for i, b in enumerate(buttons)]

def run_game_loop(screen=None, clock=None, fade_in=None, fade_out=None, player_name=None):
    if clock is None:
        clock = pygame.time.Clock()

    pygame.mixer.music.load("Music/level1_music.mp3")
    pygame.mixer.music.set_volume(0.30)
    pygame.mixer.music.play(-1)

    player = Player()
    player_group = pygame.sprite.Group(player)

    global coins
    coins = create_coins()

    running = True
    paused = False
    click_handled = False
    coin_count = 0

    pygame.font.init()
    font = pygame.font.SysFont("Segoe UI", 40, bold=True)

    while running:
        dt = clock.tick(60)
        keys = pygame.key.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                paused = not paused
                if paused:
                    pygame.mixer.music.pause()
                else:
                    pygame.mixer.music.unpause()

        if paused:
            game_surface.blit(background, (0, 0))
            draw_ground(game_surface)
            platforms.draw(game_surface)
            player_group.draw(game_surface)
            coins.draw(game_surface)
            buttons = draw_pause_menu()
            mouse_pressed = pygame.mouse.get_pressed()[0]

            if mouse_pressed and not click_handled:
                mouse_pos = pygame.mouse.get_pos()
                scaled_mouse = (mouse_pos[0] * TARGET_WIDTH // SCREEN_WIDTH, mouse_pos[1] * TARGET_HEIGHT // SCREEN_HEIGHT)
                if buttons[0].collidepoint(scaled_mouse):
                    click_sound.play()
                    paused = False
                    pygame.mixer.music.unpause()
                elif buttons[1].collidepoint(scaled_mouse):
                    click_sound.play()
                elif buttons[2].collidepoint(scaled_mouse):
                    click_sound.play()
                    return
                click_handled = True
            elif not mouse_pressed:
                click_handled = False

            continue

        player.update(keys, platforms)

        collected_coins = pygame.sprite.spritecollide(player, coins, True)
        if collected_coins:
            coin_count += len(collected_coins)
            if COIN_SOUND_ENABLED and coin_sound:
                coin_sound.play()

        if player.rect.right < 0 or player.rect.left > TARGET_WIDTH:
            coins = create_coins()
            coin_count = 0
            player.rect.x = 100
            player.rect.y = TARGET_HEIGHT - GROUND_HEIGHT - player.rect.height - 50
            player.vel_x = 0
            player.vel_y = 0
            player.jumping = False
            player.ducking = False

        game_surface.blit(background, (0, 0))
        draw_ground(game_surface)
        platforms.draw(game_surface)
        coins.draw(game_surface)
        player_group.draw(game_surface)

        # Saubere Münzanzeige oben rechts mit transparentem, abgerundetem Hintergrund
        display_rect = pygame.Rect(TARGET_WIDTH - 220, 20, 180, 60)
        overlay_surf = pygame.Surface((display_rect.width, display_rect.height), pygame.SRCALPHA)
        pygame.draw.rect(overlay_surf, (0, 0, 0, 100), overlay_surf.get_rect(), border_radius=15)
        game_surface.blit(overlay_surf, (display_rect.x, display_rect.y))

        game_surface.blit(coin_image, (display_rect.x + 15, display_rect.y + 5))
        coin_text = font.render(f"x {coin_count}", True, WHITE)
        game_surface.blit(coin_text, (display_rect.x + 75, display_rect.y + 12))

        scaled_surface = pygame.transform.scale(game_surface, (SCREEN_WIDTH, SCREEN_HEIGHT))
        screen.blit(scaled_surface, (0, 0))

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    run_game_loop()
